class GenerateBytes {
	public static void main(String[] args) throws Exception {
		generateBytes();
	}
	
	public static void generateBytes() throws Exception {
		byte temp;
		String tempS;
		MessageToBinary toBinary;
		for (int i = 0; i < 256; i++) {
			temp = (byte)i;
			tempS = ((char) (temp & 0xFF))+"";
			toBinary = new MessageToBinary(tempS);
			System.out.println(tempS+" = "+toBinary.getBinaryString());
		}
	}
}
import java.util.*;
import java.io.*;
import java.io.PrintWriter;
import java.util.Arrays;
import java.io.Console;
import java.lang.Math;

class SetUp {
	
	public static int totalStrings = 0;
	private static CoordinateEntry[][] matrix;
	public static CoordinateEntry[] bitStrings;
	public static CoordinateEntry[] blankEntries;
	public static int stringLength;
	public static int totalLocations;
	public static int numberOfBlanks;
	
	public SetUp(String[] args) {
		main(args);
	}
	
	public static void main(String[] args) {
		stringLength = 0;
		Console cons = System.console();
		if (cons == null) {
			System.err.println("No console available.");
			System.exit(1);
		}
		PrintWriter consOut = cons.writer();
		String length = args[0];
		try {
			stringLength = Integer.parseInt(length); //turn length into an integer.
		} catch (Exception e) {
			consOut.println("Error. Enter Numbers only.");
		}
		bitStrings = generateBitStrings(stringLength); //generate the array of all possible bit strings of length n.
		
		String fileInput = "MatrixInput.txt";
		String fileOutput = "MatrixOutput.txt";
		BufferedReader br = null;
		BufferedWriter bw = null;
		matrix = new CoordinateEntry[totalStrings][totalStrings]; //generate the coordinate n^4 matrix.
		int numberPerString =(int) (Math.pow(2,(2*stringLength))/(2*Math.pow(2,stringLength)));
		numberOfBlanks = totalStrings;
		System.out.println("Number of occupied spaces: "+(totalStrings*numberPerString));
		System.out.println("Number of blank spaces: "+(numberOfBlanks*numberPerString));
		blankEntries = new CoordinateEntry[numberOfBlanks]; //generate the array of all blank entries.
		try {
			String currentLine;
			int[] x,y;
			for (int i = 0; i < totalStrings; i++) {
				x = new int[totalLocations];
				y = new int[totalLocations];
				for (int j = 0; j < totalLocations; j++) {
					x[j] = (int)Math.floor(Math.random()*totalStrings);
					y[j] = (int)Math.floor(Math.random()*totalStrings);
					while (!(matrix[x[j]][y[j]] == null)) {
						x[j] = (int)Math.floor(Math.random()*(totalStrings));
						y[j] = (int)Math.floor(Math.random()*(totalStrings));
					}
					matrix[x[j]][y[j]] = bitStrings[i];
				}
				bitStrings[i].setLocationsX(x);
				bitStrings[i].setLocationsY(y);
			} 
			int blanks = 0;
			for (int i = 0; i < totalStrings; i++){
				x = new int[totalLocations];
				y = new int[totalLocations];
				blankEntries[i] = new CoordinateEntry("", true);
				for (int j = 0; j < totalLocations; j++) {
					x[j] = (int)Math.floor(Math.random()*totalStrings);
					y[j] = (int)Math.floor(Math.random()*totalStrings);
					while (!(matrix[x[j]][y[j]] == null)) {
						x[j] = (int)Math.floor(Math.random()*(totalStrings));
						y[j] = (int)Math.floor(Math.random()*(totalStrings));
					}
					matrix[x[j]][y[j]] = blankEntries[i];
				}
				blankEntries[i].setLocationsX(x);
				blankEntries[i].setLocationsY(y);

			}
			consOut.println("Total matrix size: ["+totalStrings+","+totalStrings+"]");		
		} catch (Exception e) {
			consOut.println("Unknown exception occurred. Operation terminated. Stack trace below.");
			e.printStackTrace(System.out);
		}
	}

	public static CoordinateEntry[] generateBitStrings(int stringLength) {
		int maxStrings = (int)Math.pow(2.0,((double)stringLength));
		totalStrings = maxStrings;
		totalLocations = (int) (Math.pow(2,(2*stringLength))/(2*Math.pow(2,stringLength)));
		if (stringLength >= 63) {
			System.out.println("Error. Length must be less than 63.");
		}
		CoordinateEntry[] bitStrings = new CoordinateEntry[(int)maxStrings];
		String temp;
		int max = (int)maxStrings;
		int lengthDifference = 0;
		for (int i = 0; i < max; i++) {
			temp = Integer.toBinaryString(i);
			if (temp.length() != stringLength) {
				lengthDifference = stringLength-temp.length();
				for (int j = 0; j < lengthDifference; j++){
					temp = "0"+temp;
				}
			}
			bitStrings[i] = new CoordinateEntry(temp, false);
			temp = "";
		}
		System.out.println("Total strings: "+maxStrings);
		return bitStrings;
	}
	
	public CoordinateEntry[][] getMatrix() {
		return matrix;
	}
	
	public void displayMatrix() {
		for (int i = 0; i < bitStrings.length; i++) {
			for (int j = 0; j < bitStrings.length; j++) {
				System.out.print("[");
				if (matrix[i][j].entryEmpty()) {
					for (int k = 0; k < stringLength; k++) {
						System.out.print("-");
					}
				} else {
					System.out.print(matrix[i][j].entryValue());
				}
				System.out.print("]");
			}
			System.out.println();
		}
	}
}

import java.util.*;
import java.io.*;
import java.io.PrintWriter;
import java.util.Arrays;
import java.io.Console;
import java.lang.Math;
import java.math.BigInteger;

class SetUpByteCE {
	
	public static int totalStrings = 0;
	private static ByteCE[][] matrix;
	public static ByteCE[] bitStrings;
	public static ByteCE[] blankEntries;
	public static int stringLength = 8;
	public static int totalLocations;
	public static int numberOfBlanks;
	
	public SetUpByteCE(String[] args) {
		main(args);
	}
	
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis(); //start stopwatch
		Console cons = System.console();
		if (cons == null) {
			System.err.println("No console available.");
			System.exit(1);
		}
		PrintWriter consOut = cons.writer();
		bitStrings = generateBitStrings(stringLength); //generate the array of all possible bit strings of length n.

		matrix = new ByteCE[totalStrings][totalStrings]; //generate the coordinate n^4 matrix.
		int numberPerString =(int) (Math.pow(2,(2*stringLength))/(2*Math.pow(2,stringLength)));
		numberOfBlanks = totalStrings;
		System.out.println("Number of occupied spaces: "+(totalStrings*numberPerString));
		System.out.println("Number of blank spaces: "+(totalStrings*numberPerString));
		blankEntries = new ByteCE[totalStrings]; //generate the array of all blank entries.
		try {
			String currentLine;
			int[] x, y;
			for (int i = 0; i < totalStrings; i++) {
				x = new int[totalLocations];
				y = new int[totalLocations];
				for (int j = 0; j < totalLocations; j++) {
					x[j] = (int)Math.floor(Math.random()*totalStrings);
					y[j] = (int)Math.floor(Math.random()*totalStrings);
					while (!(matrix[x[j]][y[j]] == null)) {
						x[j] = (int)Math.floor(Math.random()*(totalStrings));
						y[j] = (int)Math.floor(Math.random()*(totalStrings));
					}
					matrix[x[j]][y[j]] = bitStrings[i];
				}
				bitStrings[i].setLocationsX(x);
				bitStrings[i].setLocationsY(y);
			} 
			int blanks = 0;
			int randomBlank = 0;
			for (int i = 0; i < totalStrings; i++){
				x = new int[totalLocations];
				y = new int[totalLocations];
				blankEntries[i] = new ByteCE(true);
				for (int j = 0; j < totalLocations; j++) {
					x[j] = (int)Math.floor(Math.random()*totalStrings);
					y[j] = (int)Math.floor(Math.random()*totalStrings);
					while (!(matrix[x[j]][y[j]] == null)) {
						x[j] = (int)Math.floor(Math.random()*(totalStrings));
						y[j] = (int)Math.floor(Math.random()*(totalStrings));
					}
					matrix[x[j]][y[j]] = blankEntries[i];
				}
				blankEntries[i].setLocationsX(x);
				blankEntries[i].setLocationsY(y);
			}
			consOut.println("Total matrix size: ["+totalStrings+","+totalStrings+"]");

			long endTime = System.currentTimeMillis();
			long timeTaken = endTime-startTime;		
		} catch (Exception e) {
			consOut.println("Unknown exception occurred. Operation terminated. Stack trace below.");
			e.printStackTrace(System.out);
		}
	}

	public static ByteCE[] generateBitStrings(int stringLength) {
		int maxStrings = (int)Math.pow(2.0,((double)stringLength));
		totalStrings = maxStrings;
		totalLocations = (int) (Math.pow(2,(2*stringLength))/(2*Math.pow(2,stringLength)));
		ByteCE[] bitStrings = new ByteCE[(int)maxStrings];
		byte temp;
		int max = (int)maxStrings;
		int lengthDifference = 0;
		for (int i = 0; i < max; i++) {
			temp = (byte) i;
			bitStrings[i] = new ByteCE(temp, false);
		}
		System.out.println("Total strings: "+maxStrings);
		return bitStrings;
	}
	
	public ByteCE[][] getMatrix() {
		return matrix;
	}
}

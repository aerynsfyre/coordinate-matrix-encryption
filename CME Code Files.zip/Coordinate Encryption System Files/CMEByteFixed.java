import java.util.*;
import java.io.*;
import java.io.Console;
import java.lang.Math;

class CMEByteFixed {
	
	private static ByteCE[][] matrix;
	private static ByteCE[] blanks;
	private static ByteCE[] strings;
	private static int totalStrings, noOfBlanks;
	private static SetUpByteCE newMatrix;
	private static Console cons;
	private static String length;
	private static long megabyte = 1024L*1024L;
	private static int[] stringKey;
	
	public static void main(String[] args) throws Exception {
		//The following code completes the setup of a 256 by 256 key matrix containing all possible bytes.
		Runtime running = Runtime.getRuntime();
		running.gc();
		long setUpStart = System.currentTimeMillis();
		cons = System.console();
		String[] arg = {"8"}; //Send bit string length as argument to set up.
		newMatrix = new SetUpByteCE(arg); //Create the randomized new matrix set up.
		matrix = newMatrix.getMatrix(); //Get the matrix pointer.
		blanks = newMatrix.blankEntries; //Get the blank entries.
		strings = newMatrix.bitStrings; //Get the array of bit strings.
		totalStrings = newMatrix.totalStrings; //Get the total number of bit strings.
		noOfBlanks = newMatrix.numberOfBlanks; //Get the total number of blank entries.
		//Assign the key locations for Exclusive-OR - always the first x coordinate for each byte. List is the same for each key matrix.
		stringKey = new int[totalStrings]; 		for (int i = 0; i < totalStrings; i++) {
			stringKey[i] = strings[i].locationsX[0];
		}
		long setUpEnd = System.currentTimeMillis();
		long setUpTotal = setUpEnd-setUpStart;
		running.gc();
		long memoryInUse = running.totalMemory() - running.freeMemory();
		System.out.println("Total memory used: "+((memoryInUse*1.0)/megabyte)+" MB");
		System.out.println("Set up complete, time taken: "+setUpTotal+" ms");
		
		//This code section repeats the encryption process until the user ends it.
		Boolean continueEncrypting = true;
		String continueEncYN;
		int continueYN;
		while (continueEncrypting) {
			performEncryptDecrypt();
			continueEncYN = cons.readLine("Encrypt more data? 1 = Y, 2 = N : ");
			continueYN = Integer.parseInt(continueEncYN);
			if (continueYN == 1) {
				continueEncrypting = true;
			} else {
				continueEncrypting = false;
			}
		}
		
	}
	
	public static void performEncryptDecrypt() throws Exception {
		//Get data and run encryption/decryption.
		Runtime running = Runtime.getRuntime();
		String toEncrypt = cons.readLine("Enter data to encrypt: "); //get the plaintext.
		int stringLength = toEncrypt.length(); //check plaintext length.
		System.out.println("Entry length: "+(stringLength*8)); 
		String repeatEncryptions = cons.readLine("How many times do you want to encrypt and decrypt the data? : ");
		int repeats = Integer.parseInt(repeatEncryptions);
		int[] cipher, previous = new int[0];
		byte[] paddedVersion, plain, bitVersion;
		AnalyzeFrequencies freqOfCT;
		int intLength = stringLength;
		String convertedPT = toEncrypt;
		for (int i = 0; i < repeats; i++) { // complete the encryption/decryption process as many times as required.
			
			//Encryption: Time taken & memory in use are measured. String is converted to bytes. 
			//When not measuring memory, gc() calls should be commented out.
			//running.gc();
			//long startTime = System.currentTimeMillis();
			bitVersion = convertedPT.getBytes("UTF-8");
			cipher = encrypt(matrix, bitVersion, 8); //encrypt the plaintext.
			//long endTime = System.currentTimeMillis();
			//long encryptTime = endTime-startTime;
			//running.gc();
			//long encryptMem = running.totalMemory() - running.freeMemory();
			
			//Decryption: Time taken & memory in use are measured. Plaintext is converted back into a string. 
			//When not measuring memory, gc() calls should be commented out.
			//running.gc();
			//startTime = System.currentTimeMillis();
			plain = decrypt(matrix, cipher); //decrypt the plaintext.
			try {
				convertedPT = new String(plain, "UTF-8");
			} catch (Exception e) {}
			//endTime = System.currentTimeMillis();
			//long decryptTime = endTime-startTime;
			//running.gc();
			//long decryptMem = running.totalMemory() - running.freeMemory();
			
			//This prints the time taken for encryption and decryption, and the resulting ciphertext length.
			/*System.out.print((encryptTime)+",");
			System.out.print(decryptTime+",");
			System.out.print((cipher.length*8));
			System.out.println();
			
			//Print out the total memory used for encryption and decryption.
			System.out.println((i+1)+","+((encryptMem*1.0)/megabyte)+","+((decryptMem*1.0)/megabyte));

			//Analyze the frequencies of bytes occurring in the ciphertext.
			freqOfCT = new AnalyzeFrequencies(cipher, matrix);
			freqOfCT.displayFrequenciesAES();
			*/
			//The following section measures the difference in bytes between the current and previous ciphertexts.
			if (i > 0) {
				AvalancheEffect avEffect = new AvalancheEffect(cipher, previous);
				double diffBits = avEffect.calculateBits();
				double diffPos = avEffect.calculatePositions();
				System.out.print((i)+",");
				System.out.print((diffBits*100)+",");
				System.out.println((diffPos*100));
			}
			previous = cipher;
			
			//The following code changes a single bit of one randomly chosen byte of the plaintext, and is only used when measuring the avalanche effect.
			/*int toChange = (int) Math.floor(Math.random()*plain.length);
			byte temp = plain[toChange];
			String tempStr = ((char) (temp & 0xFF))+"";
			MessageToBinary toBin = new MessageToBinary(tempStr);
			tempStr = toBin.getBinaryString();
			int toChangeToo = (int) Math.floor(Math.random()*tempStr.length());
			String changed = "";
			if (tempStr.charAt(toChangeToo) == '0') {
				changed = tempStr.substring(0,toChangeToo)+"1"+tempStr.substring(toChangeToo+1,tempStr.length());
			} else {
				changed = tempStr.substring(0,toChangeToo)+"0"+tempStr.substring(toChangeToo+1,tempStr.length());
			}
			temp = (byte)(Integer.parseInt(changed, 2));
			plain[toChange] = temp;*/
			convertedPT = new String(plain,"UTF-8");
		}
		System.out.println("Original plaintext: " + convertedPT);
	}
	
	public static int[] encrypt(ByteCE[][] key, byte[] plaintext, int stringLength) {
		int coinToss, location, randomBlank, current, toXOR, currentX, currentY;
		int i = 0, j = 0, k = 0;
		String temp = "";
		int numberPerString = (int) (Math.pow(2,(2*stringLength))/(2*Math.pow(2,stringLength))); //Get the total possible locations for each character.
		ByteCE tempByte;
		byte currentByte;
		int blankPadding = (plaintext.length);
		int[] cipher = new int[blankPadding*4];
		while ((j < plaintext.length || k < blankPadding) && i < cipher.length) { // Ciphertext length should be exactly (plaintext*4).
			coinToss = (int)Math.floor(Math.random()*2.0); //Randomly distribute enciphered message characters among padding characters.
			
			//If coin results in heads, insert coordinates for message character.
			if (coinToss == 1 && j < plaintext.length) {
				location = (int)Math.floor(Math.random()*numberPerString);
				//Exclusive-OR the plaintext character with the next location of the key.
				toXOR = (stringKey[(j%totalStrings)]);
				current = (plaintext[j] ^ toXOR);
				if (current < 0) { current = current+255; } //If the integer of a byte is negative, move its range into [0,255].
				cipher[i] = strings[current].locationsX[location];
				cipher[i+1] = strings[current].locationsY[location];
				j++;
				i+=2;
			} else if (k < blankPadding) { //If tails, add empty padding coordinates.
				randomBlank = (int)Math.floor(Math.random()*totalStrings);
				location = (int)Math.floor(Math.random()*numberPerString);
				tempByte = blanks[randomBlank];
				cipher[i] = tempByte.locationsX[location];
				cipher[i+1] = tempByte.locationsY[location];
				k++;
				i+=2;
			}
			
		}
		return cipher;
		
	}
	
	public static byte[] decrypt(ByteCE[][] key, int[] ciphertext) {
		byte[] plaintext = new byte[ciphertext.length/4]; // Plaintext is exactly 1/4 the length of the ciphertext.
		int current = 0;
		int x, y, tempInt, toXOR;
		ByteCE temp;
		for (int i = 0; i < ciphertext.length-1 && current < plaintext.length; i=i+2) { 
			//Decrypt ciphertext coordinates two at a time.
			x = ciphertext[i];
			y = ciphertext[i+1];
			temp = key[x][y];
			if (!(temp.entryEmpty())) {
				//Exclusive-OR the resulting character with the next position in the key and add the result to the plaintext.
				toXOR = (stringKey[(current%totalStrings)]);
				tempInt = (temp.entryValue() ^ toXOR);
				plaintext[current] = (byte)tempInt;
				current++;
			}
		}
		return plaintext;
		
	}

}
import java.math.BigInteger;

class MessageToBinary {
	private char[] charSet;
	private byte[] byteSet;
	private static String binaryString;
	
	public static void main(String[] args) throws Exception {
		MessageToBinary toBinary = new MessageToBinary(args[0]);
	}
	
	public MessageToBinary(String toConvert) throws Exception {
		byteSet = toConvert.getBytes("UTF-8");
		BigInteger binaryInt = new BigInteger(byteSet);
		binaryString = binaryInt.toString(2);
	}
	
	public String xor(String one, String two, int stringLength) {
		String toReturn = "";
		for (int i = 0; i < (one.length()); i++) {
			if (one.charAt(i) == two.charAt((i)%two.length())){
				toReturn = toReturn+"0";
			} else {
				toReturn = toReturn+"1";
			}
		}
		return toReturn;
	}
	
	public MessageToBinary() {}
	
	public String getBinaryString () {
		return binaryString;
	}
	
	public String convertToCharacters(String binaryToConvert) {
		BigInteger toHex = new BigInteger(binaryToConvert,2);
		byte[] temp = toHex.toByteArray();
		String toReturn = "";
		try {
		toReturn = new String(temp, "UTF-8");
		} catch (Exception e) {}
		return toReturn;
	}

}
a=-5+10*rand;
S=X.^2-a*Y;
[X,Y]=meshgrid(-3:0.5:3,-3:0.5:3);
L=sqrt(1+S.^2);
quiver(X,Y,1./L,S./L,0.5);
axis equal tight
title('Matlab Assignment 1');
xlabel x
ylabel y
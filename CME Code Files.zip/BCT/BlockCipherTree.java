import java.security.SecureRandom;
import java.io.Console;

class BlockCipherTree {
	
	private static byte[] rangeOne = {-127, -65};
	private static byte[] rangeTwo = {-64, -1};
	private static byte[] rangeThree = {0, 63};
	private static byte[] rangeFour = {64, 127};
	private static int blockSize = 8;
	private static int centerL = 3;
	private static int centerR = 5;
	
	public static void main(String[] args) {
		try {
			//Get the runtime enviroment.
			Runtime running = Runtime.getRuntime();
			Console cons = System.console();
			//Ensure memory is clean.
			running.gc();
		
			//Begin the setup process. 
			long setUpTime, setUpStart, setUpEnd;
			setUpStart = System.currentTimeMillis();
			byte[] key = generateKey(128);
			setUpEnd = System.currentTimeMillis();
			setUpTime = setUpEnd-setUpStart;
			System.out.print("8 bit key: ");
			for (int i = 0; i < key.length; i++){
				System.out.print(key[i]+",");
			}
			System.out.println();
			System.out.println("Time to set up: "+setUpTime+" ms");
			String plaintext = cons.readLine("Enter text to encrypt: ");
			
			
			long convertStart = System.currentTimeMillis();
			byte[] unpadded = plaintext.getBytes("UTF-16");
			int padding = unpadded.length%blockSize;
			System.out.println(padding);
			byte[] plain = new byte[unpadded.length+padding];
			for (int i = 0; i < unpadded.length+padding; i++) {
				if (i < unpadded.length) {
					plain[i] = unpadded[i];
				} else {
					plain[i] = (byte)padding;
				}
			}
			long convertEnd = System.currentTimeMillis();
			long convertTotal = convertEnd-convertStart;
			for (int i = 0; i < plain.length; i++) {
				System.out.print(plain[i]+",");
			}
			System.out.println();
			long encryptStart = System.currentTimeMillis();
			byte[] cipher = encrypt(key, plain);
			long encryptEnd = System.currentTimeMillis();
			long encryptTotal = encryptEnd-encryptStart;
			System.out.print("Ciphertext: ");
			for (int i = 0; i < cipher.length; i++) {
				System.out.print(cipher[i]+",");
			}
			System.out.println();
			System.out.println("Time to encrypt: "+encryptTotal);
			long decryptStart = System.currentTimeMillis();
			byte[] decrypted = decrypt(key, cipher);
			long decryptEnd = System.currentTimeMillis();
			long decryptTotal = decryptEnd-decryptStart;
			for (int i = 0; i < decrypted.length; i++) {
				System.out.print(decrypted[i]+",");
			}
			System.out.println();
			System.out.println("Time to decrypt: "+decryptTotal);
			String finalPlain = new String(decrypted, "UTF-16");
			System.out.println("Decrypted plaintext: "+finalPlain);
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		
	}
	
	public static byte[] encrypt(byte[] key, byte[] plaintext) {
		byte[] ciphertext = new byte[plaintext.length];
		byte[] cipherRound = new byte[blockSize];
		byte[] plainTemp = new byte[blockSize];
		for (int i = 0; i < (plaintext.length-(blockSize-1)); i+=blockSize) {
			for (int j = 0; j < blockSize; j++) {
				plainTemp[j] = plaintext[i+j];
			}
			cipherRound = recursiveEncrypt(key, 0, plainTemp, 1);
			for (int j = 0; j < blockSize; j++) {
				ciphertext[i+j] = cipherRound[j];
			}
		}
		return ciphertext;
	}
	
	public static byte[] recursiveEncrypt(byte[] key, int index, byte[] currentBlock, int counter) {
		int operation = checkNextOperation(key[index]);
		byte[] roundBlock = new byte[blockSize];
		if (operation == 1) {
			roundBlock = shiftLeftOne(currentBlock);
		} else if (operation == 2) {
			roundBlock = swapEnds(currentBlock);
		} else if (operation == 3) {
			roundBlock = shiftLeftTwo(currentBlock);
		} else if (operation == 4) {
			roundBlock = swapCenter(currentBlock);
		}
		if ((counter == (blockSize)) && (index != 0)) {
			byte[] roundKey = new byte[blockSize];
			int count = 0;
			for (int i = blockSize-1; i >= 0; i--) {
				roundKey[count] = key[index-i];
				count++;
			}
			roundBlock = addRoundKey(roundBlock, roundKey);
			counter = 0;
		}
		if (index != (key.length-1)) {
			return recursiveEncrypt(key, index+1, roundBlock, (counter+1));
		} else {
			return roundBlock;
		}
	}
	
	public static byte[] decrypt(byte[] key, byte[] ciphertext) {
		byte[] plaintext = new byte[ciphertext.length];
		byte[] cipherRound = new byte[blockSize];
		byte[] plainTemp = new byte[blockSize];
		for (int i = 0; i < (ciphertext.length-(blockSize-1)); i+=blockSize) {
			for (int j = 0; j < blockSize; j++) {
				cipherRound[j] = ciphertext[i+j];
			}
			plainTemp = recursiveDecrypt(key, key.length-1, cipherRound, 0);
			for (int j = 0; j < blockSize; j++) {
				plaintext[i+j] = plainTemp[j];
			}
		}
		return plaintext;
	}
	
	public static byte[] recursiveDecrypt(byte[] key, int index, byte[] currentBlock, int counter) {
		int operation = checkNextOperation(key[index]);
		byte[] roundBlock = new byte[blockSize];
		if (counter==(0) && (index != (0))) {
			byte[] roundKey = new byte[blockSize];
			int count = 0;
			for (int i = blockSize-1; i >= 0; i--) {
				roundKey[count] = key[index-i];
				count++;
			}
			currentBlock = addRoundKey(currentBlock, roundKey);
			counter=blockSize;
		}
		if (operation == 1) {
			roundBlock = shiftRightOne(currentBlock);
		} else if (operation == 2) {
			roundBlock = swapEnds(currentBlock);
		} else if (operation == 3) {
			roundBlock = shiftRightTwo(currentBlock);
		} else if (operation == 4) {
			roundBlock = swapCenter(currentBlock);
		}
		
		if (index > 0) {
			return recursiveDecrypt(key, index-1, roundBlock, (counter-1));
		} else {
			return roundBlock;
		}
	}
	
	public static byte[] generateKey(int keyLength) {
		byte[] toReturn = new byte[keyLength];
		SecureRandom securePseudo = new SecureRandom();
		securePseudo.nextBytes(toReturn);
		return toReturn;
	}
	
	public static int checkNextOperation(byte keyByte) {
		int toReturn = 0;
		int toCheck = (int)keyByte;
		if (toCheck >= rangeOne[0] && toCheck <= rangeOne[1]){
			toReturn = 1;
		} else if (toCheck >= rangeTwo[0] && toCheck <= rangeTwo[1]) {
			toReturn = 2;
		} else if (toCheck >= rangeThree[0] && toCheck <= rangeThree[1]) {
			toReturn = 3;
		} else if (toCheck >= rangeFour[0] && toCheck <= rangeFour[1]) {
			toReturn = 4;
		}
		return toReturn;
	}
	
	public static byte[] shiftLeftOne(byte[] toShift) {
		byte[] toReturn = new byte[blockSize];
		int shifted;
		for (int i = 0; i < blockSize; i++) {
			shifted =((((i-1)%blockSize)+blockSize)%blockSize);
			toReturn[shifted] = toShift[i];
		}
		return toReturn;
	}
	
	public static byte[] shiftLeftTwo(byte[] toShift) {
		byte[] toReturn = new byte[blockSize];
		int shifted;
		for (int i = 0; i < blockSize; i++) {
			shifted = ((((i-2)%blockSize)+blockSize)%blockSize);
			toReturn[shifted] = toShift[i];
		}
		return toReturn;
	}
	
	public static byte[] swapEnds(byte[] toSwap) {
		byte[] toReturn = new byte[blockSize];
		for (int i = 0; i < blockSize; i++) {
			toReturn[i] = toSwap[i];
		}
		toReturn[0] = toSwap[blockSize-1];
		toReturn[blockSize-1] = toSwap[0];
		return toReturn;
	}
	
	public static byte[] swapCenter(byte[] toSwap) {
		byte[] toReturn = new byte[blockSize];
		for (int i = 0; i < blockSize; i++) {
			toReturn[i] = toSwap[i];
		}
		toReturn[centerL] = toSwap[centerR];
		toReturn[centerR] = toSwap[centerL];
		return toReturn;
	}
	
	public static byte[] addRoundKey(byte[] round, byte[] key){
		byte[] toReturn = new byte[blockSize];
		//System.out.print("Key: ");
		for (int i = 0; i < blockSize; i++) {
			toReturn[i] = (byte)((round[i]) ^ (key[i]));
			//System.out.print(key[i]+",");
		}
		/*System.out.println();
		System.out.print("Round: ");
		for (int i = 0; i < blockSize; i++) {
			System.out.print(round[i]+",");
		}
		System.out.println();
		System.out.print("Result: ");
		for (int i = 0; i < blockSize; i++) {
			System.out.print(toReturn[i]+",");
		}
		System.out.println();*/
		return toReturn;
	}
	
	public static byte[] shiftRightOne(byte[] toShift) {
		byte[] toReturn = new byte[blockSize];
		int shifted;
		for (int i = 0; i < blockSize; i++) {
			shifted = ((((i+1)%blockSize)+blockSize)%blockSize);
			toReturn[shifted] = toShift[i];
		}
		return toReturn;
	}
	
	public static byte[] shiftRightTwo(byte[] toShift) {
		byte[] toReturn = new byte[blockSize];
		int shifted;
		for (int i = 0; i < blockSize; i++) {
			shifted = ((((i+2)%blockSize)+blockSize)%blockSize);
			toReturn[shifted] = toShift[i];
		}
		return toReturn;
	}
}
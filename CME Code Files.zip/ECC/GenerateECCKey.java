import java.security.*;
import java.security.spec.*;

class GenerateECCKey {
	
	private static PublicKey sharedKey;
	private static PrivateKey secretKey;
	
	public GenerateECCKey(String[] args) throws Exception {
		main(args);
	}
	
	public static void main(String[] args) throws Exception {
		KeyPairGenerator generate;
		generate = KeyPairGenerator.getInstance("EC", "SunEC");
		ECGenParameterSpec specs;
		specs = new ECGenParameterSpec("secp192r1");
		generate.initialize(specs);
		
		KeyPair pair = generate.genKeyPair();
		secretKey = pair.getPrivate();
		sharedKey = pair.getPublic();

	}
	
	public PrivateKey getPrivateKey() { return secretKey; }
	
	public PublicKey getPublicKey() { return sharedKey; }
}
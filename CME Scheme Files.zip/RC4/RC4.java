import java.security.*;
import javax.crypto.*;
import java.io.Console;

class RC4 {
	static String plaintext;
	static String encryptionKey;
 	static byte[] initVBytes;	
  	static SecureRandom pseudoRNG;
  	static long megabyte = 1024L*1024L;
  	static Console cons;
	static SecretKey randomRC4Key;
	static Cipher rC4Cipher;
	
	public static void main(String[] args) throws Exception {
		Runtime running = Runtime.getRuntime();
		System.out.println("RC4 Encryption with Random 128 bit key");
		cons = System.console();
		long setUpTime, setUpStart, setUpEnd;
		
		//Initiate setup.
		running.gc();
		setUpStart = System.currentTimeMillis();
		SetUp();
		Boolean keepEncrypting = true;
		int encryptYN = 0;
		setUpEnd = System.currentTimeMillis();
		setUpTime = setUpEnd-setUpStart;
		System.out.println("Set up complete, time taken: "+setUpTime+" ms");
		running.gc();
		long memoryInUse = running.totalMemory() - running.freeMemory();
		System.out.println("Total memory used: "+((memoryInUse*1.0)/megabyte)+" MB");
		
		while (keepEncrypting) {
			String plaintext = cons.readLine("Enter plaintext to encrypt: ");
			int encryptTimes = Integer.parseInt(cons.readLine("Enter number of times to encrypt the data: "));
			byte[] previous = new byte[0];
			for (int i = 0; i < encryptTimes; i++) {
				running.gc();
			  	long startTime, endTime, encryptTime, decryptTime;
			  	startTime = System.currentTimeMillis();
		      	byte[] cipher = encrypt(plaintext);
			  	endTime = System.currentTimeMillis();
			  	encryptTime = endTime-startTime;
				running.gc();
				long encryptMem = running.totalMemory() - running.freeMemory();
						
				//The following code measures the change in ciphertext from the previous output to the current one.
				if (i > 0) {
					AvalancheEffect avEffect = new AvalancheEffect(cipher, previous);
					double diffBits = avEffect.calculateBits();
					double diffPos = avEffect.calculatePositions();
					System.out.print((i)+",");
					System.out.print((diffBits*100)+",");
					System.out.println((diffPos*100));
				}
			
				AnalyzeFrequencies freqAnalysis = new AnalyzeFrequencies(cipher);
				freqAnalysis.displayFrequenciesAES();
				
				running.gc();
				startTime = System.currentTimeMillis();
		     	String decrypted = decrypt(cipher);
			  	endTime = System.currentTimeMillis();
			  	decryptTime = endTime-startTime;
			
				running.gc();
				long decryptMem = running.totalMemory() - running.freeMemory();
				previous = cipher;
		      	System.out.println("decrypt: " + decrypted);

				//Print the time taken to encrypt and decrypt the data.
			  	System.out.print(encryptTime+",");
			  	System.out.print(decryptTime+",");
				System.out.print((cipher.length*8));
				System.out.println();
				
				//The following code changes a single bit of one randomly chosen byte of the plaintext, and is only used when measuring the avalanche effect.
				int toChange = (int) Math.floor(Math.random()*plaintext.length());
				char temp = plaintext.charAt(toChange);
				String tempStr = temp+"";
				MessageToBinary toBin = new MessageToBinary(tempStr);
				tempStr = toBin.getBinaryString();
				int toChangeToo = (int) Math.floor(Math.random()*tempStr.length());
				String changed = "";
				if (tempStr.charAt(toChangeToo) == '0') {
					changed = tempStr.substring(0,toChangeToo)+"1"+tempStr.substring(toChangeToo+1,tempStr.length());
				} else {
					changed = tempStr.substring(0,toChangeToo)+"0"+tempStr.substring(toChangeToo+1,tempStr.length());
				}
				byte tmpByte = (byte)(Integer.parseInt(changed, 2));
				temp = (char)(tmpByte & 0xFF);
				plaintext = plaintext.substring(0,toChange)+temp+plaintext.substring(toChange+1, plaintext.length());
				
				//The below code checks the overall memory used for the processes of encryption and decryption.
				running.gc();
				memoryInUse = running.totalMemory() - running.freeMemory();
				System.out.println((i+1)+","+((encryptMem*1.0)/megabyte)+","+((decryptMem*1.0)/megabyte));
			}
				
			encryptYN = Integer.parseInt(cons.readLine("Do you want to keep encrypting with this key? 1=Y, 2=N : "));
			if (encryptYN == 2) {
				keepEncrypting = false;
			} 
			
		}

	}
	
	public static void SetUp() throws Exception {
		SecureRandom initVector = new SecureRandom();
		KeyGenerator kGen = KeyGenerator.getInstance("RC4");
		kGen.init(128);
		randomRC4Key = kGen.generateKey();
		rC4Cipher = Cipher.getInstance("RC4");
	}
	
	public static byte[] encrypt(String plaintext) throws Exception {
		rC4Cipher.init(Cipher.ENCRYPT_MODE, randomRC4Key);
		byte[] ciphertext = rC4Cipher.doFinal(plaintext.getBytes());
		return ciphertext;
	}
	
	public static String decrypt(byte[] ciphertext) throws Exception {
		rC4Cipher.init(Cipher.DECRYPT_MODE, randomRC4Key);
		byte[] plaintext = rC4Cipher.doFinal(ciphertext);
		return new String(plaintext,"UTF-8");
	}
	
}
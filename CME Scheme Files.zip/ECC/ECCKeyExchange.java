import java.math.BigInteger;
import java.security.*;
import java.security.spec.*;
import javax.crypto.KeyAgreement;

class ECCKeyExchange {
	
	private static KeyAgreement keyAV, keyAU;
	private static BigInteger secretU, secretV;
	private static long megabyte = 1024L*1024L;
	
	public static void main(String[] args) throws Exception {
		Runtime running = Runtime.getRuntime();
		running.gc();
		long setupStart = System.currentTimeMillis();
		GenerateECCKey keyPairU = new GenerateECCKey(args);
		GenerateECCKey keyPairV = new GenerateECCKey(args);
		
		keyAU = KeyAgreement.getInstance("ECDH");
		keyAU.init(keyPairU.getPrivateKey());
		keyAU.doPhase(keyPairV.getPublicKey(), true);
		
		keyAV = KeyAgreement.getInstance("ECDH");
		keyAV.init(keyPairV.getPrivateKey());
		keyAV.doPhase(keyPairU.getPublicKey(), true);
		
		secretU = new BigInteger(1, keyAU.generateSecret());
		secretV = new BigInteger(1, keyAV.generateSecret());
		
		long setupEnd = System.currentTimeMillis();
		long setupTotalTime = setupEnd-setupStart;
		running.gc();
		long memoryInUse = running.totalMemory() - running.freeMemory();
		System.out.println("Secret computed by U: "+ (secretU.toString(16)).toUpperCase());
		System.out.println("Secret computed by V: "+ (secretV.toString(16)).toUpperCase());
		System.out.println("Total time for setup: "+setupTotalTime+" ms");
		System.out.println("Total memory used: "+((memoryInUse*1.0)/megabyte)+" MB");
		
		
	}
}
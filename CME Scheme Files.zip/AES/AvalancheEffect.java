import java.io.Console;

class AvalancheEffect {
	
	private static int bitsDiffer, positionsDiffer;
	private static byte[] bOne, bTwo;

	public AvalancheEffect(byte[] bytesOne, byte[] bytesTwo) {
		bOne = bytesOne;
		bTwo = bytesTwo;
	}
	
	public AvalancheEffect() {}
	
	//Calculate the total number of the same bytes occurring in the two ciphertexts.
	public double calculateBits() { 
		int matches = 0;
		double percentMatch;
		for (int i = 0; i < bOne.length; i++) {
			for (int j = 0; j < bTwo.length; j++) {
				if (bOne[i] == bTwo[j]) {
					matches++;
					break;
				}
			}
		}
		percentMatch = ((matches*1.0)/bOne.length);
		return percentMatch;
	}
	
	//Calculate the total number of bytes occurring in the same positions in the two ciphertexts.
	public double calculatePositions() {
		int matches = 0;
		double percentMatch;
		for (int i = 0; i < bOne.length; i++) {
			if (bOne[i] == bTwo[i]) {
				matches++;
			}
		}
		percentMatch = ((matches*1.0)/bOne.length);
		return percentMatch;
		
	}
}
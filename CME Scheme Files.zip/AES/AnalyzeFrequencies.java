class AnalyzeFrequencies {
	private Frequency[] frequencies;
	private int totalValues;
	private int[] occurances;
	
	public static void main(String[] args) {
		
	}
	
	//Takes as input an array of bytes and measures the occurences of each byte.
	public AnalyzeFrequencies(byte[] ciphertext) { 
			totalValues = ciphertext.length;
			frequencies = new Frequency[totalValues];
			for (int i = 0; i < totalValues; i++) {
				frequencies[i] = new Frequency("", 0, true, "none", "");
			}
	 		String temp, xString, yString;
			String actualVal = "none";
			String bitValue = "";
			Boolean exists = false;
			int noOfEntries = 0;
			int x,y;
			byte[] buffer = new byte[1];
			Boolean matrixEntryEmpty = true;
			for (int i = 0; i < ciphertext.length-1; i++) {
				temp = (new Integer(ciphertext[i])+"");
				for (int j = 0; j < totalValues; j++) {
					if (frequencies[j].valueEqual(temp)) {
						frequencies[j].updateOccurances();
						exists = true;
						break;
					} 
				}
				if (!exists) {
					noOfEntries++;
					frequencies[noOfEntries].setFreqValue(temp);
					frequencies[noOfEntries].updateOccurances();
					frequencies[noOfEntries].setEmpty(false);
					} 
				exists = false;
			}
		
			}
			
		public void displayFrequenciesAES() {
			maxOccurBytes();
			for (int i = 1; i < occurances.length; i++) {
				System.out.print(occurances[i] + ",");
			}
			System.out.println();
		}
			
		public void maxOccurBytes() {
			int max = 0;
			for (int i = 0; i < totalValues; i++) {
				if (max < frequencies[i].getOccurances()) {
					max = frequencies[i].getOccurances();
				}
			}
			occurances = new int[max+1];
			int current = 0;
			for (int i = 0; i < totalValues; i++) {
				current = frequencies[i].getOccurances();
				occurances[current]++;
			}
		}
	
}

class Frequency {
	private String freqValue;
	private int noOfOccurances;
	private Boolean isEmpty;
	private String actualValue;
	private String bitValue;
	
	public Frequency(String value, int occurances, Boolean empty, String val, String bits) {
		freqValue = value;
		noOfOccurances = occurances;
		isEmpty = empty;
		actualValue = val;
		bitValue = bits;
	}
	
	public void setBitValue(String bits) { bitValue = bits; }
	
	public String getBitValue() { return bitValue; }
	
	public void updateOccurances() { noOfOccurances++; }
	
	public int getOccurances() { return noOfOccurances; }
	
	public void setEmpty(Boolean empty) { isEmpty = empty; }
	
	public Boolean isEmpty() { return isEmpty; }
	
	public void setActualVal(String val) { actualValue = val; }
	
	public String getActualVal() { return actualValue; }
	
	public void setFreqValue(String value) { freqValue = value; }
	
	public Boolean valueEqual(String toCheck) {
		if (toCheck.equals(freqValue)) {
			return true;
		} else {
			return false;
		}
	}
	
	public String getValue() { return freqValue; }
}
import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.io.Console;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.*;
import java.security.SecureRandom;

public class AES {
  	static String plaintext;
	static String encryptionKey;
  	static byte[] initVBytes;
  	static SecureRandom pseudoRNG;
  	static long megabyte = 1024L*1024L;
  	static Console cons;

  public static void main(String [] args) {
    try {
		Runtime running = Runtime.getRuntime();
		running.gc();
      	System.out.println("AES Encryption with Randomly Generated Key");
	  	cons = System.console();
	  	Boolean keepEncrypting = true;
		int encryptYN = 0;
		long setUpTime, setUpStart, setUpEnd;
		
		//Generate a random 128-bit key and initialisation vector.
		encryptionKey = "128";
		setUpStart = System.currentTimeMillis();
		KeyGenerator secretKey = KeyGenerator.getInstance("AES");
		secretKey.init(Integer.parseInt(encryptionKey));
		SecretKey randomAESKey = secretKey.generateKey();
		initVBytes = new byte[Integer.parseInt(encryptionKey)/8];
		pseudoRNG = new SecureRandom();
		pseudoRNG.nextBytes(initVBytes);
		setUpEnd = System.currentTimeMillis();
		setUpTime = setUpEnd-setUpStart;
		System.out.println("Set up complete, time taken: "+setUpTime+" ms");
		running.gc();
		long memoryInUse = running.totalMemory() - running.freeMemory();
		System.out.println("Total memory used: "+((memoryInUse*1.0)/megabyte)+" MB");
		
		//Encrypt the user entered data.
		while (keepEncrypting) {
	  		plaintext = cons.readLine("Enter plaintext: ");
	  		int encryptTimes = Integer.parseInt(cons.readLine("Enter times to encrypt the data: "));
			byte[] previous = new byte[0];
      		System.out.println("plain:   " + plaintext);
			for (int i = 0; i < encryptTimes; i++) {
				running.gc();
	  			long startTime, endTime, encryptTime, decryptTime;
	  			startTime = System.currentTimeMillis();
      			byte[] cipher = encrypt(plaintext, randomAESKey);
	  			endTime = System.currentTimeMillis();
	  			encryptTime = endTime-startTime;
				running.gc();
				long encryptMem = running.totalMemory() - running.freeMemory();
				
				//The following code measures the change in ciphertext from the previous output to the current one.
				if (i > 0) {
					AvalancheEffect avEffect = new AvalancheEffect(cipher, previous);
					double diffBits = avEffect.calculateBits();
					double diffPos = avEffect.calculatePositions();
					System.out.print((i)+",");
					System.out.print((diffBits*100)+",");
					System.out.println((diffPos*100));
				}
			
				AnalyzeFrequencies freqAnalysis = new AnalyzeFrequencies(cipher);
				freqAnalysis.displayFrequenciesAES();
				running.gc();
	 			startTime = System.currentTimeMillis();
      			String decrypted = decrypt(cipher, randomAESKey);
	  			endTime = System.currentTimeMillis();
	  			decryptTime = endTime-startTime;
				running.gc();
				long decryptMem = running.totalMemory() - running.freeMemory();
				previous = cipher;
      			System.out.println("decrypt: " + decrypted);

				//Print the time taken to encrypt and decrypt the data.
	  			System.out.print(encryptTime+",");
	  			System.out.print(decryptTime+",");
				System.out.print((cipher.length*8));
				System.out.println();
				
				//The following code changes a single bit of one randomly chosen byte of the plaintext, and is only used when measuring the avalanche effect.
				int toChange = (int) Math.floor(Math.random()*plaintext.length());
				char temp = plaintext.charAt(toChange);
				String tempStr = temp+"";
				MessageToBinary toBin = new MessageToBinary(tempStr);
				tempStr = toBin.getBinaryString();
				int toChangeToo = (int) Math.floor(Math.random()*tempStr.length());
				String changed = "";
				if (tempStr.charAt(toChangeToo) == '0') {
					changed = tempStr.substring(0,toChangeToo)+"1"+tempStr.substring(toChangeToo+1,tempStr.length());
				} else {
					changed = tempStr.substring(0,toChangeToo)+"0"+tempStr.substring(toChangeToo+1,tempStr.length());
				}
				byte tmpByte = (byte)(Integer.parseInt(changed, 2));
				temp = (char)(tmpByte & 0xFF);
				plaintext = plaintext.substring(0,toChange)+temp+plaintext.substring(toChange+1, plaintext.length());
				
				//The below code checks the overall memory used for the processes of encryption and decryption.
				running.gc();
				memoryInUse = running.totalMemory() - running.freeMemory();
				System.out.println((i+1)+","+((encryptMem*1.0)/megabyte)+","+((decryptMem*1.0)/megabyte));
			}
			
			encryptYN = Integer.parseInt(cons.readLine("Do you want to keep encrypting with this key? 1=Y, 2=N : "));
			if (encryptYN == 2) {
				keepEncrypting = false;
			} 
	
		}

    } catch (Exception e) {
      e.printStackTrace();
    } 
  }

  public static byte[] encrypt(String plaintext, SecretKey secretKey) throws Exception {
    Cipher encryption = Cipher.getInstance("AES/CBC/PKCS5Padding");
    encryption.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(initVBytes));
    return encryption.doFinal(plaintext.getBytes("UTF-8"));
  }

  public static String decrypt(byte[] ciphertext, SecretKey secretKey) throws Exception{
    Cipher decryption = Cipher.getInstance("AES/CBC/PKCS5Padding");
    decryption.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(initVBytes));
    return new String(decryption.doFinal(ciphertext),"UTF-8");
  }
}
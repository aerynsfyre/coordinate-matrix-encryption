import java.io.Console;
class GenerateBinaryString {
	public static void main(String[] args) {
		Console cons = System.console();
		String length = cons.readLine("Enter length of random binary string : ");
		int stringLength = Integer.parseInt(length);
		int toss;
		String randString = "";
		for (int i = 0; i < stringLength; i++) {
			toss = (int)(Math.random()*2);
			if (toss == 0) { randString = randString+"0"; }
			else { randString = randString+"1"; }
		}
		System.out.println("Random generated string : "+randString);
	}
}
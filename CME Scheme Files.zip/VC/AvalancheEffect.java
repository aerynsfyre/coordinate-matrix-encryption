import java.io.Console;

class AvalancheEffect {
	
	private static int bitsDiffer, positionsDiffer;
	private static int[] bOne, bTwo;
	private static byte[] byOne, byTwo;
	
	public AvalancheEffect() {}
	
	public static double stringPos(String one, String two) {
		int matches = 0;
		double percentMatch;
		for (int i = 0; i < one.length(); i++) {
			if (one.charAt(i) == two.charAt(i)) {
				matches++;
			}
		}
		percentMatch = ((matches*1.0)/one.length());
		return percentMatch;
	}
}
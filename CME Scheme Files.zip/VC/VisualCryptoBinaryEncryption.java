import java.io.Console;

class VisualCryptoBinaryEncryption {
	
	public static int possibleSubPixelStates = 6;
	public static String randomShareOne, shareTwo;
	private static long megabyte = 1024L*1024L;
	
	public static void main(String[] args) {
		Runtime running = Runtime.getRuntime();
		running.gc();
		Console cons = System.console();
		long setupStart = System.currentTimeMillis(); //start counter for setup time.
		String[] subPixelsOne = subPixelStatesOne();
		String[] subPixelsTwo = subPixelStatesTwo();
		long setupEnd = System.currentTimeMillis(); //end counter for setup time.
		long setupTotal = setupEnd-setupStart;
		running.gc();
		long setupMem = running.totalMemory() - running.freeMemory();
		System.out.println("Set up complete. Time taken: "+setupTotal+" ms.");
		System.out.println("Total memory used: "+((setupMem*1.0)/megabyte)+" MB");
		System.out.println();
		
		String plaintext = cons.readLine("Enter plaintext to encrypt into shares: "); //get the binary plaintext string.
		String encryptTimes = cons.readLine("Enter number of times encryption/decryption should be performed: "); //get the number of repetitions.
		int repetitions = Integer.parseInt(encryptTimes);
		String previousShareOne = "";
		long encryptMem, decryptMem;
		for (int i = 0; i < repetitions; i++) { //perform the repeated encryptions.
			running.gc();
			long encryptStart = System.currentTimeMillis();
			generateRandomShare(plaintext, subPixelsOne, subPixelsTwo); //split the binary plaintext string into shares.
			long encryptEnd = System.currentTimeMillis();
			long encryptTotal = encryptEnd-encryptStart;
			running.gc();
			encryptMem = running.totalMemory() - running.freeMemory();
			System.out.println("Encryption #"+(i+1));
			System.out.println("Shares generated. Time taken: "+encryptTotal+" ms."); //display the shares.
			System.out.println("Share one: "+randomShareOne);
			System.out.println("Share two: "+shareTwo);
			System.out.println("Share length: "+shareTwo.length()+" bits.");
			if (i > 0) {
				AvalancheEffect avEffect = new AvalancheEffect();
				double percentSame = avEffect.stringPos(previousShareOne, randomShareOne);
				System.out.println(i+","+(percentSame*100));
			}
			running.gc();
			long decryptStart = System.currentTimeMillis();
			String combined = recombineShares(randomShareOne, shareTwo); //recombine the shares into decrypted plaintext.
			long decryptEnd = System.currentTimeMillis();
			long decryptTotal = decryptEnd-decryptStart;
			decryptMem = running.totalMemory() - running.freeMemory();
			System.out.println((i+1)+","+((encryptMem*1.0)/megabyte)+","+((decryptMem*1.0)/megabyte));
			System.out.println("Shares recombined. Time taken: "+decryptTotal+" ms.");
			System.out.println("Decrypted plaintext: "+combined);
			Boolean matches = combined.equals(plaintext); //check combined shares matches original plaintext.
			System.out.println("Decrypted plaintext matches original data: "+matches);
			System.out.println();
			previousShareOne = randomShareOne;
			//The following code alters the inputted plaintext by exactly one bit, allowing for measure of the avalanche effect.
			int randPos = (int)Math.floor((Math.random()*(plaintext.length())));
			String temp = "";
			if (plaintext.charAt(randPos) == '0') {
				temp = plaintext.substring(0, (randPos))+"1"+plaintext.substring((randPos+1), plaintext.length());
			} else {
				temp = plaintext.substring(0, (randPos))+"0"+plaintext.substring((randPos+1), plaintext.length());
			}
			plaintext = temp;
		}
		
	}
	
	public static String[] subPixelStatesOne() {
		String[] subPixelStringsOne = {"0101", "1010", "1100", "0011", "0110", "1001"}; //generate the first array of possible subpixel states.
		return subPixelStringsOne;
	}
	
	public static String[] subPixelStatesTwo() {
		String[] subPixelStringsTwo = {"1010", "0101", "0011", "1100", "1001", "0110"}; //generate the second array of possible subpixel states.
		return subPixelStringsTwo;
	}
	
	public static void generateRandomShare(String toSplit, String[] subPixelStringsOne, String[] subPixelStringsTwo) {
		randomShareOne = "";
		shareTwo = "";
		int randomSubPixel;
		char currentPixel;
		for (int i = 0; i < toSplit.length(); i++) {
			randomSubPixel = (int)Math.floor(Math.random()*possibleSubPixelStates); //pick a random subpixel state.
			currentPixel = toSplit.charAt(i);
			randomShareOne = randomShareOne + subPixelStringsOne[randomSubPixel];   //assign the random subpixel state to the first share.
			if (currentPixel == '1') {			//if the pixel equals 1, assign the opposite subpixel state to the second share.
				shareTwo = shareTwo + subPixelStringsTwo[randomSubPixel];
			} else {							//if the pixel equals 0, assign the same subpixel state to the second share.
				shareTwo = shareTwo + subPixelStringsOne[randomSubPixel];
			}
		}
	}
	
	public static String recombineShares(String sOne, String sTwo) {
		String combined = "";
		String tempOne, tempTwo;
		for (int i = 0; i < sOne.length()-3; i+=4) {
			tempOne = sOne.substring(i,i+4);
			tempTwo = sTwo.substring(i,i+4);
			if (tempOne.equals(tempTwo)) {
				combined = combined+"0";
			} else {
				combined = combined+"1";
			}
		}
		return combined;
	}
}
class AnalyzeFrequencies {
	private Frequency[] frequencies;
	private int totalValues, noOfEntries;
	private int[] blankOccur, fullOccur, bytesOccur;
	private String[] mostOccurances;
	
	public static void main(String[] args) {
		
	}
	
	public AnalyzeFrequencies(String ciphertext, int valueLength, CoordinateEntry[][] matrix) {
		totalValues = (int)Math.abs(Math.ceil(ciphertext.length()/(valueLength)));
		frequencies = new Frequency[totalValues];
		for (int i = 0; i < totalValues; i++) {
			frequencies[i] = new Frequency("", 0, true, "none", "");
		}
 		String temp, xString, yString;
		String actualVal = "none";
		String bitValue = "";
		Boolean exists = false;
		noOfEntries = 0;
		int x,y;
		byte[] buffer = new byte[1];
		Boolean matrixEntryEmpty = true;
		for (int i = 0; i <= (ciphertext.length()-(valueLength*2)); i=i+(2*valueLength)) {
			temp = ciphertext.substring(i,i+(2*valueLength));
			xString = temp.substring(0, (valueLength));
			yString = temp.substring((valueLength), temp.length());
			x = Integer.parseInt(xString, 2);
			y = Integer.parseInt(yString, 2);
			if (!(matrix[x][y].entryEmpty())) {
				matrixEntryEmpty = false;
				bitValue = matrix[x][y].entryValue();
				
			} 
			
			for (int j = 0; j < totalValues; j++) {
				if (frequencies[j].valueEqual(temp)) {
					frequencies[j].updateOccurances();
					exists = true;
					break;
				} 
			}
			if (!exists) {
				frequencies[noOfEntries].setFreqValue(temp);
				frequencies[noOfEntries].updateOccurances();
				frequencies[noOfEntries].setEmpty(false);
				frequencies[noOfEntries].setBitValue(bitValue);
				noOfEntries++;
			}
			exists = false;
			bitValue = "";
			
		}
	}
	
	public void displayFrequencies() {
		maxOccurances();
		for (int i = 1; i < blankOccur.length; i++) {
			System.out.print(blankOccur[i]+","+fullOccur[i]+",");
		}
		System.out.println();
	}
	
	public void maxOccurances() {
		int maxBlank = 0;
		int maxFull = 0;
		for (int i = 0; i < noOfEntries; i++) {
			if (!(frequencies[i].bitEqual("")) && (maxFull < frequencies[i].getOccurances())) {
				maxFull = frequencies[i].getOccurances();
			} else if (frequencies[i].bitEqual("") && (maxBlank < frequencies[i].getOccurances())) {
				maxBlank = frequencies[i].getOccurances();
			}
		}
		int largest = Math.max(maxBlank,maxFull);
		blankOccur = new int[largest+1];
		fullOccur = new int[largest+1];
		int current = 0;
		for (int i = 0; i < noOfEntries; i++) {
			current = frequencies[i].getOccurances();
			if (!(frequencies[i].bitEqual(""))) {
				fullOccur[current]++;
			} else if (frequencies[i].bitEqual("")) {
				blankOccur[current]++;
			}
		}
	}
	
	public AnalyzeFrequencies(int[] ciphertext, ByteCE[][] matrix) {
			totalValues = ciphertext.length;
			frequencies = new Frequency[totalValues];
			for (int i = 0; i < totalValues; i++) {
				frequencies[i] = new Frequency("", 0, true, "none", "");
			}
	 		String temp, xString, yString;
			String actualVal = "none";
			String bitValue = "";
			Boolean exists = false;
			noOfEntries = 0;
			int x,y;
			int[] buffer = new int[2];
			Boolean matrixEntryEmpty = true;
			int i = 0;
			while (i < (ciphertext.length-1)) {
				x = ciphertext[i];
				y = ciphertext[i+1];
				temp = x+","+y;
				i+=2;
				for (int j = 0; j < totalValues; j++) {
					if (frequencies[j].valueEqual(temp)) {
						frequencies[j].updateOccurances();
						exists = true;
						actualVal = "none";
						break;
					} 
				}
				if (!(matrix[x][y].entryEmpty())) {
					actualVal = ""+(char)(matrix[x][y].entryValue()& 0xFF);
				} else {
					actualVal = "none";
				}
				if (!exists) {
					frequencies[noOfEntries].setFreqValue(temp);
					frequencies[noOfEntries].updateOccurances();
					frequencies[noOfEntries].setEmpty(false);
					frequencies[noOfEntries].setActualVal(actualVal);
					noOfEntries++;
				}
				exists = false;
				
			}
	}
			
		public void displayFrequenciesAES() {
			maxOccurBytes();
			for (int i = 1; i < blankOccur.length; i++) {
				System.out.print(blankOccur[i] + ","+fullOccur[i]+",");
			}
			System.out.println();
		}
		
		public void maxOccurBytes() {
			int maxBlank = 0;
			int maxFull = 0;
			for (int i = 0; i < totalValues; i++) {
				if ((!(frequencies[i].valEqual("none"))) && (maxFull < frequencies[i].getOccurances())) {
					maxFull = frequencies[i].getOccurances();
				} else if (frequencies[i].valEqual("none") && (maxBlank < frequencies[i].getOccurances())) {
					maxBlank = frequencies[i].getOccurances();
				}
			}
			int largest = Math.max(maxBlank,maxFull);
			blankOccur = new int[largest+1];
			fullOccur = new int[largest+1];
			mostOccurances = new String[largest+1];
			int current = 0;
			for (int i = 0; i < noOfEntries; i++) {
				current = frequencies[i].getOccurances();
				if (!(frequencies[i].valEqual("none"))) {
					fullOccur[current]++;
					mostOccurances[current] = mostOccurances[current]+frequencies[i].getActualVal()+",";
				} else if (frequencies[i].valEqual("none")) {
					blankOccur[current]++;
				}
				
			}
		}

	
}

class Frequency {
	private String freqValue;
	private int noOfOccurances;
	private Boolean isEmpty;
	private String actualValue;
	private String bitValue;
	
	public Frequency(String value, int occurances, Boolean empty, String val, String bits) {
		freqValue = value;
		noOfOccurances = occurances;
		isEmpty = empty;
		actualValue = val;
		bitValue = bits;
	}
	
	public void setBitValue(String bits) { bitValue = bits; }
	
	public String getBitValue() { return bitValue; }
	
	public Boolean bitEqual(String check) { 
		Boolean toReturn = (check.equals(bitValue));
		return toReturn;
	}
	
	public void updateOccurances() { noOfOccurances++; }
	
	public int getOccurances() { return noOfOccurances; }
	
	public void setEmpty(Boolean empty) { isEmpty = empty; }
	
	public Boolean isEmpty() { return isEmpty; }
	
	public void setActualVal(String val) { actualValue = val; }
	
	public String getActualVal() { return actualValue; }
	
	public Boolean valEqual(String check) { 
		Boolean toReturn = (check.equals(actualValue));
		return toReturn;
	}
	
	public void setFreqValue(String value) { freqValue = value; }
	
	public Boolean valueEqual(String toCheck) {
		Boolean toReturn = (toCheck.equals(freqValue));
		return toReturn;
	}
	
	public String getValue() { return freqValue; }
}
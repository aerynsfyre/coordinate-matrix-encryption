class ByteCE {
	
	private byte bitValue;
	private Boolean isEmpty;
	private int locationX;
	private int locationY;
	public int[] locationsX;
	public int[] locationsY;
	
	public static void main(String[] args) {}
	
	public ByteCE(byte bitVal, Boolean empty) {
		bitValue = bitVal;
		isEmpty = empty;
	}
	
	public ByteCE(Boolean empty) {
		isEmpty = empty;
	}
	
	public Boolean entryEmpty() {
		return isEmpty;
	}
	
	public byte entryValue() {
		return bitValue;
	}
	
	public int getLocationX() {
		return locationX;
	}
	
	public void setLocationX(int x) {
		locationX = x;
	}
	
	public int getLocationY() {
		return locationY;
	}
	
	public void setLocationY(int y) {
		locationY = y;
	}
	
	public int[] getLocationsX() {
		return locationsX;
	}
	
	public void setLocationsX(int[] x) {
		locationsX = x;
	}
	
	public int[] getLocationsY() {
		return locationsY;
	}
	
	public void setLocationsY(int[] y) {
		locationsY = y;
	}
}
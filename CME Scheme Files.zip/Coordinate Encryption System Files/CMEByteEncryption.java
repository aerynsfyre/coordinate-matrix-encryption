import java.util.*;
import java.io.*;
import java.io.PrintWriter;
import java.util.Arrays;
import java.io.Console;
import java.lang.Math;
import java.math.BigInteger;

class CMEByteEncryption {
	
	private static ByteCE[][] matrix;
	private static ByteCE[] blanks;
	private static ByteCE[] strings;
	private static int totalStrings;
	private static SetUpByteCE newMatrix;
	private static int noOfBlanks;
	private static Console cons;
	private static String length;
	
	public static void main(String[] args) throws Exception {
		cons = System.console();
		String[] arg = {"8"}; //send bit string length as argument to set up.
		newMatrix = new SetUpByteCE(arg); //create the randomized new matrix set up.
		matrix = newMatrix.getMatrix(); //get the matrix pointer.
		blanks = newMatrix.blankEntries; //get the blank entries.
		strings = newMatrix.bitStrings; //get the array of bit strings.
		totalStrings = newMatrix.totalStrings; //get the total number of bit strings.
		noOfBlanks = newMatrix.numberOfBlanks; //get the total number of blank entries.

		Boolean continueEncrypting = true;
		String continueEncYN;
		int continueYN;
		while (continueEncrypting) {
			performEncryptDecrypt();
			continueEncYN = cons.readLine("Encrypt more data? 1 = Y, 2 = N : ");
			continueYN = Integer.parseInt(continueEncYN);
			if (continueYN == 1) {
				continueEncrypting = true;
			} else {
				continueEncrypting = false;
			}
		}
		
	}
	
	public static void performEncryptDecrypt() throws Exception {
		String toEncrypt = cons.readLine("Enter data to encrypt: "); //get the plaintext.
		long toConvertStart = System.currentTimeMillis();
		byte[] bitVersion = toEncrypt.getBytes("UTF-8");
		long toConvertEnd = System.currentTimeMillis();
		long toConvertTotal = toConvertEnd-toConvertStart;
		int stringLength = bitVersion.length; //check plaintext length.
		System.out.println("Time to convert to bytes: "+toConvertTotal+" ms.");
		System.out.println("Entry length: "+(stringLength*8)); 
		String repeatEncryptions = cons.readLine("How many times do you want to encrypt and decrypt the data? : ");
		int repeats = Integer.parseInt(repeatEncryptions);
		ArrayList<Integer> cipher;
		byte[] paddedVersion;
		byte[] plain = new byte[1];
		AnalyzeFrequencies freqOfCT;
		int intLength = stringLength;
		String convertedPT = "";
		for (int i = 0; i < repeats; i++) { // complete the encryption/decryption process as many times as required.
			long startTime = System.currentTimeMillis();
			cipher = encrypt(matrix, bitVersion, 8); //encrypt the plaintext.
			long endTime = System.currentTimeMillis();
			long timeTaken = endTime-startTime;
			System.out.println("Encryption #"+(i+1));
			System.out.println();
			System.out.println("Time to encrypt: "+(timeTaken+toConvertTotal)+" ms");
			System.out.println("Length of ciphertext: "+(cipher.size()*8));
			startTime = System.currentTimeMillis();
			plain = decrypt(matrix, cipher); //decrypt the plaintext.
			try {
				convertedPT = new String(plain, "UTF-8");
			} catch (Exception e) {}
			endTime = System.currentTimeMillis();
			timeTaken = endTime-startTime;
			System.out.println("Time to decrypt: "+timeTaken+" ms");
			System.out.println();
			//freqOfCT = new AnalyzeFrequencies(cipher, intLength, matrix, isAlpha);
			//freqOfCT.displayFrequencies(isAlpha);
			
		}
		System.out.println("Original plaintext: " + convertedPT);
		
		 
	}
	
	public static ArrayList<Integer> encrypt(ByteCE[][] key, byte[] plaintext, int stringLength) {
		int coinToss = 0;
		String temp = "";
		int location, lengthDifference, randomBlank, blankX, blankY;
		int xBit, yBit;
		int i = 0;
		int numberPerString = (int) (Math.pow(2,(2*stringLength))/(2*Math.pow(2,stringLength)));
		int currentX, currentY;
		ByteCE tempByte;
		int current;
		int j = 0;
		int k = 0;
		int blankPadding = plaintext.length;
		ArrayList<Integer> cipher = new ArrayList<Integer>();
		while (j < plaintext.length || k < blankPadding) {
			coinToss = (int)Math.floor(Math.random()*2.0);
			if (coinToss == 1 && j < plaintext.length) {
				location = (int)Math.floor(Math.random()*numberPerString);
				current = (plaintext[j]);
				if (current < 0) { current = current+255; }
				cipher.add(strings[current].locationsX[location]);
				cipher.add(strings[current].locationsY[location]);
				j++;
			} else if (coinToss == 0 && k < blankPadding) {
				location = (int)Math.floor(Math.random()*noOfBlanks);
				tempByte = blanks[location];
				cipher.add(tempByte.getLocationX());
				cipher.add(tempByte.getLocationY());
				k++;
			} else if (k < blankPadding) {
				location = (int)Math.floor(Math.random()*noOfBlanks);
				tempByte = blanks[location];
				cipher.add(tempByte.getLocationX());
				cipher.add(tempByte.getLocationY());
				k++;
			}
			i++;
			
		}

		return cipher;
		
	}
	
	public static byte[] decrypt(ByteCE[][] key, ArrayList<Integer> ciphertext) {
		byte[] buffer = new byte[ciphertext.size()];
		int nonEmptyLocations = 0;
		int x, y, current;
		ByteCE temp;
		for (int i = 0; i < ciphertext.size()-1; i=i+2) {
			x = ciphertext.get(i);
			y = ciphertext.get(i+1);
			temp = key[x][y];
			if (!(temp.entryEmpty())) {
				buffer[nonEmptyLocations] = temp.entryValue();
				nonEmptyLocations++;
			}
		}
		byte[] plaintext = new byte[nonEmptyLocations];
		for (int i = 0; i < plaintext.length; i++){
			plaintext[i] = buffer[i];
		}
		return plaintext;
		
	}


}
class CoordinateEntry {
	
	private String bitValue;
	private Boolean isEmpty;
	private int locationX;
	private int locationY;
	public int[] locationsX;
	public int[] locationsY;
	
	public static void main(String[] args) {}
	
	public CoordinateEntry(String bitVal, Boolean empty) {
		bitValue = new String(bitVal+"");
		isEmpty = empty;
	}
	
	public Boolean entryEmpty() { return isEmpty; }
	
	public String entryValue() { return bitValue; }
	
	public int getLocationX() { return locationX; }
	
	public void setLocationX(int x) { locationX = x; }
	
	public int getLocationY() { return locationY; }
	
	public void setLocationY(int y) { locationY = y; }
	
	public int[] getLocationsX() { return locationsX; }
	
	public void setLocationsX(int[] x) { locationsX = x; }
	
	public int[] getLocationsY() { return locationsY; }
	
	public void setLocationsY(int[] y) { locationsY = y; }
}
import java.math.BigInteger;

class MessageToBits {
	private char[] charSet;
	private byte[] byteSet;
	private String binaryString;
	
	public static void main(String[] args) {
		
	}
	
	public MessageToBits(String toConvert) throws Exception {
		byteSet = toConvert.getBytes("UTF-8");
		BigInteger binaryInt = new BigInteger(toConvert.getBytes("UTF-8"));
		binaryString = binaryInt.toString(2);
	}
	
	public byte[] getBytes () {
		return byteSet;
	}
	
	public String convertToCharacters(byte[] bytesToConvert) {
		try {
			String toReturn = new String(bytesToConvert, "UTF-8");
			return toReturn;
		} catch (Exception e) {}
		return "failed to convert";
	}

}
import java.io.Console;

class AvalancheEffect {
	
	private static int bitsDiffer, positionsDiffer;
	private static int[] bOne, bTwo;
	
	public static void main(String[] args) {
		Console cons = System.console();
		String sOne = cons.readLine("Enter ciphertext one: ");
		String sTwo = cons.readLine("Enter ciphertext two: ");
		double posChanged = stringPos(sOne, sTwo);
		System.out.println("Bits same: "+(posChanged*100)+"%");
	}

	public AvalancheEffect(int[] bytesOne, int[] bytesTwo) {
		bOne = bytesOne;
		bTwo = bytesTwo;
	}
	
	public AvalancheEffect() {}
	
	public double calculateBits() {
		int matches = 0;
		double percentMatch;
		for (int i = 0; i < bOne.length; i++) {
			for (int j = 0; j < bTwo.length; j++) {
				if (bOne[i] == bTwo[j]) {
					matches++;
					break;
				}
			}
		}
		percentMatch = ((matches*1.0)/bOne.length);
		return percentMatch;
	}
	
	public double calculatePositions() {
		int matches = 0;
		double percentMatch;
		for (int i = 0; i < bOne.length; i++) {
			if (bOne[i] == bTwo[i]) {
				matches++;
			}
		}
		percentMatch = ((matches*1.0)/bOne.length);
		return percentMatch;
		
	}
	
	public double stringBits(String one, String two) {
		int matches = 0;
		double percentMatch;
		for (int i = 0; i < one.length(); i++) {
			for (int j = 0; j < two.length(); j++) {
				if (one.charAt(i) == two.charAt(j)) {
					matches++;
					break;
				}
			}
		}
		percentMatch = ((matches*1.0)/one.length());
		return percentMatch;
	}
	
	public static double stringPos(String one, String two) {
		int matches = 0;
		double percentMatch;
		for (int i = 0; i < one.length(); i++) {
			if (one.charAt(i) == two.charAt(i)) {
				matches++;
			}
		}
		percentMatch = ((matches*1.0)/one.length());
		return percentMatch;
	}
}
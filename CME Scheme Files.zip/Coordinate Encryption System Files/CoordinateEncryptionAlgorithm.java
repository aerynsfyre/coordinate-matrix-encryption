import java.util.*;
import java.io.*;
import java.io.PrintWriter;
import java.util.Arrays;
import java.io.Console;
import java.lang.Math;

class CoordinateEncryptionAlgorithm {
	
	private static CoordinateEntry[][] matrix;
	private static CoordinateEntry[] blanks;
	private static CoordinateEntry[] strings;
	private static int totalStrings;
	private static SetUp newMatrix;
	private static int noOfBlanks;
	private static Console cons;
	private static String length, xorString;
	private static long megabyte = 1024L*1024L;
	private static byte[] forXOR;
	
	public static void main(String[] args) throws Exception {
		Runtime running = Runtime.getRuntime();
		running.gc();
		long setupStart = System.currentTimeMillis();
		cons = System.console();
		length = "4"; 
		String[] arg = {length}; //Send bit string length as argument to set up.
		newMatrix = new SetUp(arg); //Create the randomized new matrix set up.
		matrix = newMatrix.getMatrix(); //Get the matrix pointer.
		blanks = newMatrix.blankEntries; //Get the blank entries.
		strings = newMatrix.bitStrings; //Get the array of bit strings.
		totalStrings = newMatrix.totalStrings; //Get the total number of bit strings.
		noOfBlanks = newMatrix.numberOfBlanks; //Get the total number of blank entries.
		forXOR = new byte[totalStrings];
		int temp = 0;
		for (int i = 0; i < totalStrings; i++) {
			temp = strings[i].locationsX[0];
			forXOR[i] = (byte)temp;
		}
		MessageToBinary bin = new MessageToBinary(new String(forXOR,"UTF-8"));
		xorString = bin.getBinaryString();
		double divisor = ((double)xorString.length()/((double)newMatrix.stringLength));
		if (Math.floor(divisor) != divisor) {
			xorString = padPlaintext(xorString, divisor, Integer.parseInt(length));
		}
		long setupEnd = System.currentTimeMillis();
		long setupTotal = setupEnd-setupStart;
		newMatrix.displayMatrix();
		running.gc();
		long setupMem = running.totalMemory() - running.freeMemory();
		System.out.println("Set up complete, time taken: "+setupTotal+" ms.");
		System.out.println("Total memory used: "+((setupMem*1.0)/megabyte)+" MB");
		Boolean continueEncrypting = true;
		String continueEncYN;
		int continueYN;
		while (continueEncrypting) { //Continue encrypting & decrypting until the user ends the process.
			performEncryptDecrypt();
			continueEncYN = cons.readLine("Encrypt more data? 1 = Y, 2 = N : ");
			continueYN = Integer.parseInt(continueEncYN);
			if (continueYN == 1) {
				continueEncrypting = true;
			} else {
				continueEncrypting = false;
			}
		}
		
	}
	
	public static void performEncryptDecrypt() throws Exception {
		String toEncrypt = cons.readLine("Enter data to encrypt: "); //get the plaintext.
		String original = toEncrypt;
		Boolean isAlpha;
		String alphaYN = cons.readLine("Is the text in binary format? Y/N: ");
		alphaYN = alphaYN.toUpperCase();
		MessageToBinary toBin = new MessageToBinary();
		if (alphaYN.equals("N")){
			toBin = new MessageToBinary(toEncrypt);
			toEncrypt = toBin.getBinaryString();
			isAlpha = true;
		}
		else { isAlpha = false; }
		int stringLength = toEncrypt.length(); //check plaintext length.
		System.out.println("Entry length: "+stringLength); 
		double divisor = ((double)stringLength/((double)newMatrix.stringLength)); //check if plaintext requires padding.
		String repeatEncryptions = cons.readLine("How many times do you want to encrypt and decrypt the data? : ");
		int repeats = Integer.parseInt(repeatEncryptions);
		System.out.println("Divisor: "+divisor);
		String cipher, paddedVersion;
		String plain = "";
		Boolean padded;
		AnalyzeFrequencies freqOfCT;
		long padStart = System.currentTimeMillis();
		long encryptMem, decryptMem;
		Runtime running = Runtime.getRuntime();
		if (Math.floor(divisor) == divisor) {
			System.out.println("Entry does not require padding.");
			padded = false;
			paddedVersion = toEncrypt;
		} else {
			paddedVersion = padPlaintext(toEncrypt, divisor, Integer.parseInt(length));
			padded = true;
		}
		long padEnd = System.currentTimeMillis();
		long padTotal = padEnd-padStart;
		int intLength = Integer.parseInt(length);
		String converted = paddedVersion;
		String previous = "";
		for (int i = 0; i < repeats; i++) { // complete the encryption/decryption process as many times as required.
			//Encryption: Time taken & memory in use are measured.
			//When not measuring memory, gc() calls should be commented out.
			running.gc();
			long startTime = System.currentTimeMillis();
			paddedVersion = toBin.xor(converted, xorString, Integer.parseInt(length));
			cipher = encrypt(matrix, paddedVersion, intLength, intLength); //encrypt the plaintext.
			long endTime = System.currentTimeMillis();
			long encryptTime = endTime-startTime;
			running.gc();
			encryptMem = running.totalMemory() - running.freeMemory();
			
			//Decryption: Time taken & memory in use are measured.
			//When not measuring memory, gc() calls should be commented out.
			running.gc();
			startTime = System.currentTimeMillis();
			plain = decrypt(matrix, cipher, intLength); //decrypt the plaintext.
			converted = toBin.xor(plain, xorString, Integer.parseInt(length));
			endTime = System.currentTimeMillis();
			long decryptTime = endTime-startTime;
			running.gc();
			System.out.println("Plaintext:");
			System.out.println(plain);
			System.out.println("Ciphertext:");
			System.out.println(cipher);
			decryptMem = running.totalMemory() - running.freeMemory();
			
			//This prints the time taken and memory in use for encryption & decryption.
			System.out.println((encryptTime+padTotal)+" "+(decryptTime+padTotal)+" "+cipher.length());
			System.out.println((i+1)+","+((encryptMem*1.0)/megabyte)+","+((decryptMem*1.0)/megabyte));
			
			//The following measures the frequencies of the characters in the ciphertext.
			freqOfCT = new AnalyzeFrequencies(cipher, intLength, matrix);
			freqOfCT.displayFrequencies();
						
			//This section measures the avalanche effect of the algorithm, comparing the current and previous ciphertexts.
			if (i > 0) {
				AvalancheEffect avEffect = new AvalancheEffect();
				double percentSame = avEffect.stringPos(cipher, previous);
				System.out.println(i+" "+(percentSame*100));
			}
			previous = cipher;
			
			//This section changes the plaintext by exactly one bit. It is only used when measuring the avalanche effect.
			int randPos = (int)Math.floor((Math.random()*(plain.length())));
			if (plain.charAt(randPos) == '0') {
				toEncrypt = plain.substring(0, (randPos))+"1"+plain.substring((randPos+1), plain.length());
			} else {
				toEncrypt = plain.substring(0, (randPos))+"0"+plain.substring((randPos+1), plain.length());
			}
		} 
		plain = toBin.xor(plain, xorString, Integer.parseInt(length));
		if (padded) {
			plain = removePadding(plain, divisor, Integer.parseInt(length));
		}
		if (isAlpha) {
			plain = toBin.convertToCharacters(plain);
		} 
		String convertedPT = "";
		System.out.println("Decoded binary string matches original input: "+(plain.equals(original)));
	}
	
	public static String encrypt(CoordinateEntry[][] key, String plaintext, int stringLength, int length) {
		String ciphertext = "";
		int coinToss = 0;
		String temp = "";
		int location, lengthDifference, randomBlank, blankX, blankY;
		String xBit, yBit;
		int i = 0;
		int j = 0;
		int blankPadding = plaintext.length();
		while (i < plaintext.length() || j < blankPadding) {
			coinToss = (int) Math.floor(Math.random()*2.0);
			if (coinToss == 0 && i < plaintext.length()) {
				temp = temp + plaintext.substring(i, i+length); //get the next n bits of the string.
				location = Integer.parseInt(temp, 2); //find the int equivalent of the bit string
				if (location < 0) { location+=255; }
				int chosenLocation = (int) Math.floor(Math.random()*newMatrix.totalLocations);
				xBit = Integer.toBinaryString(strings[location].locationsX[chosenLocation]);
				if (xBit.length() != stringLength) { //make sure the bit string for location x is nbits long.
					lengthDifference = stringLength-xBit.length();
					for (int k = 0; k < lengthDifference; k++){
						xBit = "0"+xBit;
					}
				}
				yBit = Integer.toBinaryString(strings[location].locationsY[chosenLocation]);
				if (yBit.length() != stringLength) { //make sure the bit string for location y is nbits long.
					lengthDifference = stringLength-yBit.length();
					for (int k = 0; k < lengthDifference; k++){
						yBit = "0"+yBit;
					}
				}
				ciphertext = ciphertext+xBit+yBit; //update ciphertext with new piece of string, bit strings for location x & y.
				temp = ""; //clear temp for next bit section.
				i = i+length; //move ahead to next bit section.
				location = 0;
			} else if (j < blankPadding) {
				randomBlank = (int)Math.abs(Math.random()*noOfBlanks);
				int chosenLocation = (int) Math.floor(Math.random()*newMatrix.totalLocations);
				blankX = blanks[randomBlank].locationsX[chosenLocation];
				blankY = blanks[randomBlank].locationsY[chosenLocation];
				xBit = Integer.toBinaryString(blankX);
				if (xBit.length() != stringLength) { //make sure the bit string for location x is nbits long.
					lengthDifference = stringLength-xBit.length();
					for (int k = 0; k < lengthDifference; k++){
						xBit = "0"+xBit;
					}
				}
				yBit = Integer.toBinaryString(blankY);
				if (yBit.length() != stringLength) { //make sure the bit string for location y is nbits long.
					lengthDifference = stringLength-yBit.length();
					for (int k = 0; k < lengthDifference; k++){
						yBit = "0"+yBit;
					}
				}
				ciphertext = ciphertext+xBit+yBit; //update ciphertext with new piece of string, bit strings for location x & y.
				j=j+length;
			}
		}
		
		return ciphertext;
		
	}
	
	public static String decrypt(CoordinateEntry[][] key, String ciphertext, int stringLength) {
		String plaintext = "";
		int i = 0;
		int x,y,j;
		String xBit, yBit;
		String temp = "";
		while (i < ciphertext.length()) {
			temp = ciphertext.substring(i,i+stringLength);
			i=i+stringLength;//update i for next location.
			x = Integer.parseInt(temp, 2);//get integer value for binary string.
			temp = ""; //clear temp for next location.
			temp = ciphertext.substring(i,i+stringLength);
			i = i+stringLength; //update i for next location.
			y = Integer.parseInt(temp, 2); //get integer value for binary string.
			temp = ""; //clear temp for next location.
			if (!matrix[x][y].entryEmpty()) { //test if entry is padding or message
				plaintext = plaintext+matrix[x][y].entryValue(); //if message, add value to cipher text.
			}
		}
		
		return plaintext;
		
	}
	
	public static String padPlaintext(String plaintext, double divisor, int length) {
		int padding = (int) (Math.ceil(divisor)*length);
		padding = padding-plaintext.length();
		for (int i = 0; i < padding; i++) {
			plaintext = plaintext + "0";
		}
		return plaintext;
		
	}
	
	public static String removePadding(String ciphertext, double divisor, int length) {
		double padding = (divisor*length);
		int paddingToRemove = (int) ((Math.ceil(divisor)*length)-padding);
		System.out.println("Amount of padding to remove: "+paddingToRemove);
		String temp = "";
		for (int i = 0; i < (ciphertext.length()-paddingToRemove); i++) {
			temp = temp+ ciphertext.charAt(i);
		}
		return ciphertext = temp;
		
	}

}